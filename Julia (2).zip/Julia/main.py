from flask import Flask,render_template,request,url_for,redirect,session
import os
from flaskext.mysql import MySQL
from flask_session import Session

app = Flask(__name__, template_folder='templates',static_folder='static')
basedir = os.path.abspath(os.path.dirname(__file__))
mysql = MySQL()
SESSION_TYPE = 'redis'
#BANCO DE DADOS -> MYSQL
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = '262626ry'
app.config['MYSQL_DATABASE_DB'] = 'audote'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
#FIM DO BANCO
Session(app)
mysql.init_app(app)
conn = mysql.connect()
cursor = conn.cursor()

@app.route("/index")
@app.route("/")
def index():
    try:
        if session['email'] != None:
            return render_template("index.html")
        else:
            return redirect("/login")
    except:
        return redirect("/login")

@app.route("/registrar", methods = ['POST', 'GET'])
def registrar():
    if request.method == 'POST':
        nome_usuario = request.form['nome']
        senha_usuario = request.form['senha']
        email_usuario = request.form['email']
        telefone_usuario = request.form['telefone']

        cursor.execute(f"INSERT INTO login(email,senha,nome,telefone) VALUES('{email_usuario}','{senha_usuario}','{nome_usuario}','{telefone_usuario}')")
        data = cursor.fetchone()
        conn.commit()
        return render_template("login.html")
    else:
        return render_template("registrar.html")


@app.route("/login",methods = ['POST','GET'])
def login():
    if request.method == 'POST':
        email_usuario = request.form['email']
        senha_usuario = request.form['senha']
        cursor.execute(f"SELECT * FROM login WHERE email = '{email_usuario}' AND senha = '{senha_usuario}'")
        logado = cursor.fetchone()
        if logado:
            session['email'] = email_usuario
            return redirect("/")
        else:
            return render_template("login.html")
    return render_template("login.html")

@app.route("/cadastroCachorro", methods = ['POST','GET'])
def cadastroCachorro():
    try:
        if session['email'] != None:
            print(session['email'])
            if request.method == 'POST':
                nome_cachorro = request.form['nome_cachorro']
                idade_cachorro = request.form['idade_cachorro']
                descricao_cachorro = request.form['descricao_cachorro']
                imagem_cachorro = request.form['imagem_cachorro']
                print(f"Imagem do Cachorro: {imagem_cachorro}")
                raca_cachorro = request.form['raca_cachorro']
                cursor.execute(f"INSERT INTO cadastro_cachorro(nome_cachorro,idade_cachorro,descricao_cachorro,imagem_cachorro,raca_cachorro) VALUES('{nome_cachorro}','{idade_cachorro}','{descricao_cachorro}','{imagem_cachorro}','{raca_cachorro}')")
                conn.commit()
                return redirect("/")
            return render_template("cadastroCachorro.html")
        else:
            return redirect("/login")
    except Exception as e:
        print(e)
        return redirect("/login")
    
@app.route("/adote")
def adote():
    try:
        if session['email'] != None:
            print(session['email'])
            cursor.execute(f"SELECT * FROM cadastro_cachorro")
            cachorro_lista = cursor.fetchall()
            print(cachorro_lista)
            return render_template("adote.html",cachorro_lista=cachorro_lista)
        else:
            return redirect("/login")
    except Exception as e:
        print(e)
        return redirect("/login")

@app.route("/adotar/<id>", methods = ["GET","POST"])
def adotar(id):
    try:
        if session['email'] != None:
            print(session['email'])
            id = id
            if request.method == 'POST':
                cursor.execute(f"DELETE FROM cadastro_cachorro WHERE id='{id}'")
                return redirect("/")
            else:
                cursor.execute(f"SELECT * FROM cadastro_cachorro WHERE id='{id}'")
                adotar_cachorro = cursor.fetchone()
                return render_template("adotar.html",adotar_cachorro=adotar_cachorro)
        else:
            return redirect("/login")
    except:
        return redirect("/login")


@app.route("/logout")
def logout():
    try:
        print(session['email'])
        session['email'] = None
        return redirect("/login")
    except:
        session['email'] = None
        return redirect("/login")

@app.route("/sobre")
def sobre():
    try:
        if session['email'] != None:
            return render_template("sobre.html")
        else:
            return redirect("/login")
    except:
            return redirect("/login")

if __name__ == '__main__':
    app.run(debug=True)